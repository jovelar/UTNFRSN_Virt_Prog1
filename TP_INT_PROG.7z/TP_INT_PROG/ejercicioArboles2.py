import arbol2
arbol=arbol2.ArbolBinario()

arbol.insertar(1)
arbol.insertar(20)
arbol.insertar(50)
arbol.insertar(-1)
arbol.insertar(100)
arbol.insertar(7)

arbol.mostrar()